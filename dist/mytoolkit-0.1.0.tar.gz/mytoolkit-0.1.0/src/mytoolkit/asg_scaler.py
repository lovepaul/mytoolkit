# src/mytoolkit/asg_scaler.py

import boto3
import typer
from colorama import Fore, Style

from mytoolkit.utils import echo_error, get_logger

app = typer.Typer(add_completion=False)

def log_echo(logger, msg: str, color: str = None):
    """
    同时输出到终端和日志：
      - color: 如 Fore.GREEN / Fore.RED，None 则无色
    """
    console = color + msg + Style.RESET_ALL if color else msg
    typer.echo(console)
    logger.info(msg)

@app.command("scale-asg")
def scale_asg():
    """
    交互式地根据 EC2 tag:Name（实例 Name 即 ASG 名）模糊搜索并列出 ASG，
    然后展示所选 ASG 的详细配置并引导执行扩缩容更新。
    """
    cmd_name = "scale-asg"
    logger = get_logger(cmd_name)

    # 1. 打印并确认 AWS 环境
    sts = boto3.client("sts")
    ident = sts.get_caller_identity()
    account_id = ident["Account"]
    try:
        alias = boto3.client("iam").list_account_aliases()["AccountAliases"][0]
    except Exception:
        alias = None
    region = boto3.session.Session().region_name or boto3.client("ec2").meta.region_name
    env_msg = f"AWS 环境 -> Account: {alias or account_id}, Region: {region}"
    log_echo(logger, env_msg)
    if not typer.confirm("确认在上述环境中执行操作？", default=False):
        log_echo(logger, "用户取消操作", color=Fore.RED)
        raise typer.Exit(0)

    # 2. 输入服务关键词
    svc = typer.prompt("请输入服务关键词 (实例 Name 标签)")
    logger.info(f"服务关键词: {svc}")

    # 3. 用 EC2 DescribeInstances + tag:Name + running 过滤
    ec2 = boto3.client("ec2")
    resp = ec2.describe_instances(
        Filters=[
            {"Name": "tag:Name", "Values": [f"*{svc}*"]},
            {"Name": "instance-state-name", "Values": ["running"]}
        ]
    )
    # 收集实例的 Name 标签（对应 ASG 名）
    instance_names = []
    for r in resp.get("Reservations", []):
        for ins in r.get("Instances", []):
            name = next((t["Value"] for t in ins.get("Tags", [])
                         if t["Key"] == "Name"), None)
            if name:
                instance_names.append(name)

    if not instance_names:
        log_echo(logger, f"未找到与 “{svc}” 相关的运行中实例。退出。", color=Fore.RED)
        raise typer.Exit(1)

    # 4. 去重并列出所有 ASG 名称及其实例数
    asg_names = sorted(set(instance_names))
    log_echo(logger, "\n搜索到以下 ASG 及其实例数：")
    for i, name in enumerate(asg_names, start=1):
        count = instance_names.count(name)
        log_echo(logger, f"  {i}. {name} (Instances: {count})")

    # 5. 用户选择
    idx = typer.prompt("请选择要操作的编号", type=int)
    logger.info(f"选择编号: {idx}")
    if idx < 1 or idx > len(asg_names):
        log_echo(logger, "无效编号，退出。", color=Fore.RED)
        raise typer.Exit(1)
    selected_asg = asg_names[idx - 1]
    log_echo(logger, f"用户选择 ASG：{selected_asg}")

    # 6. 查询该 ASG 的详细配置
    asg_cli = boto3.client("autoscaling")
    detail = asg_cli.describe_auto_scaling_groups(
        AutoScalingGroupNames=[selected_asg]
    )["AutoScalingGroups"][0]
    curr_min = detail["MinSize"]
    curr_des = detail["DesiredCapacity"]
    curr_max = detail["MaxSize"]
    created = detail["CreatedTime"].strftime("%Y-%m-%d %H:%M:%S")

    log_echo(logger, "\n当前 ASG 配置：")
    log_echo(logger, f"  Name    : {selected_asg}")
    log_echo(logger, f"  Created : {created}")
    log_echo(logger, f"  Desired : {Fore.GREEN}{curr_des}{Style.RESET_ALL}")
    log_echo(logger, f"  Min     : {Fore.GREEN}{curr_min}{Style.RESET_ALL}")
    log_echo(logger, f"  Max     : {Fore.GREEN}{curr_max}{Style.RESET_ALL}")

    # 7. 交互式输入新值，默认回车采用当前
    new_des = typer.prompt("输入新的 Desired 容量", type=int, default=curr_des)
    new_min = typer.prompt("输入新的 Min 容量",     type=int, default=curr_min)
    new_max = typer.prompt("输入新的 Max 容量",     type=int, default=curr_max)
    logger.info(f"新配置 -> Desired: {new_des}, Min: {new_min}, Max: {new_max}")

    # 8. 验证 Min <= Desired <= Max
    if not (new_min <= new_des <= new_max):
        log_echo(logger, "错误：需满足 Min <= Desired <= Max，退出。", color=Fore.RED)
        raise typer.Exit(1)

    # 9. 显示对比并确认更新
    log_echo(logger, "\n计划应用更改：")
    log_echo(logger, f"  Desired: {curr_des} -> {new_des}", color=Fore.RED)
    log_echo(logger, f"  Min    : {curr_min} -> {new_min}", color=Fore.RED)
    log_echo(logger, f"  Max    : {curr_max} -> {new_max}", color=Fore.RED)
    if not typer.confirm("确认执行更新？", default=False):
        log_echo(logger, "操作已取消。", color=Fore.RED)
        raise typer.Exit(0)

    # 10. 调用 AWS 更新并展示结果
    try:
        asg_cli.update_auto_scaling_group(
            AutoScalingGroupName=selected_asg,
            MinSize=new_min,
            DesiredCapacity=new_des,
            MaxSize=new_max,
        )
        log_echo(logger, f"✅ 已更新 ASG {selected_asg}", color=Fore.GREEN)

        # 重新读取并展示最新配置
        detail = asg_cli.describe_auto_scaling_groups(
            AutoScalingGroupNames=[selected_asg]
        )["AutoScalingGroups"][0]
        log_echo(logger, "\n更新后 ASG 配置：")
        log_echo(logger, f"  Desired : {Fore.GREEN}{detail['DesiredCapacity']}{Style.RESET_ALL}")
        log_echo(logger, f"  Min     : {Fore.GREEN}{detail['MinSize']}{Style.RESET_ALL}")
        log_echo(logger, f"  Max     : {Fore.GREEN}{detail['MaxSize']}{Style.RESET_ALL}")
    except Exception as e:
        echo_error(f"更新失败：{e}")
        logger.error(f"更新异常：{e}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()